const hamburger = document.querySelector('.hamburger');
const nav = document.querySelector('nav');
const navLinks = document.querySelectorAll('nav a'); // Pilih semua link di dalam nav

// Toggle sidebar saat hamburger ditekan
hamburger.addEventListener('click', () => {
    nav.classList.toggle('show'); // Toggle class 'show'
});

// Tutup sidebar saat link ditekan
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        nav.classList.remove('show'); // Hapus class 'show'
    });
});
